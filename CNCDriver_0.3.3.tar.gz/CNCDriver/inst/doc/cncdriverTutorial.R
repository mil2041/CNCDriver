## ----knitrSetup, include=FALSE-------------------------------------------
library(knitr)
opts_chunk$set(out.extra='style="display:block; margin: auto"', fig.align="center", fig.width=12, fig.height=12, tidy=TRUE)

## ----style, include=FALSE, echo=FALSE, results='asis'--------------------
BiocStyle::markdown()

## ----installCNCDriver, eval=FALSE----------------------------------------
#  library(remotes)
#  install_github(repo="mil2041/CNCDriver", ref="master", build_vignette=TRUE)

## ----loadLibrary, message=FALSE, warning=FALSE---------------------------
library(CNCDriver)

## ----searchHelp, eval=FALSE, tidy=FALSE----------------------------------
#  help.search("CNCDriver")

## ----showHelp, eval=FALSE, tidy=FALSE------------------------------------
#  # ftp://ftp.sanger.ac.uk/pub/cancer/AlexandrovEtAl
#  help(geneConnector)
#  ?geneConnector

