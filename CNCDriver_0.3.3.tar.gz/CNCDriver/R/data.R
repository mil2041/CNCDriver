#' @title reduced funseq2 CDS output for LGG
#' @description This data contains the topology of a 
#' circuit with ten genes A1...A5 and B1...B5. 
#' @format A data frame with 18 rows and 3 variables
"reducedFunseqOutputCDS"

#' @title reduced funseq2 NCDS output for LGG
#' @description This data contains the topology of a 
#' circuit with ten genes A1...A5 and B1...B5. 
#' @format A data frame with 18 rows and 3 variables
"reducedFunseqOutputNCDS"