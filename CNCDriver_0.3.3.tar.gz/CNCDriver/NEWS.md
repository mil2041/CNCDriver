CNCDriver release v0.3.0
date 2018-10-26
bugs fix
